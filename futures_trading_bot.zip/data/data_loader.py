# Load market and news data
