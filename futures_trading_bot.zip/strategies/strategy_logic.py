# Main trading strategy logic
