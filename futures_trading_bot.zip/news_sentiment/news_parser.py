# Parse and analyze financial news
