# Custom technical indicator functions
