# Futures Trading Bot

This bot uses technical indicators, news sentiment, order flow, and machine learning to trade futures markets.